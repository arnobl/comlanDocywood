// Javascript code here.
// Use the variable 'obj' to format it as expected in the variable 'res'.
// For instance:
// res = "'" + obj.toString() + "'"
// Helper methods can be coded here as in any Javascript file.
res = '[[ ' + obj.toString() + " ]]\n";
